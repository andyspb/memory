enyo-cordova
============

Enyo-compatible library to automatically include platform-specific Cordova library (WIP)
